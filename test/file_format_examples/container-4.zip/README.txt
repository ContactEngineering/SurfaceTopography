
Contents of this ZIP archive
============================
This archive contains 2 digital surface twin(s). Each digital surface
twin is a collection of individual topography measurements. In total,
this archive contains 2 topography measurements.

There are two files for each measurement:
- The original data file which was uploaded by a user,
- as alternative, a NetCDF 3 file with extension "-squeezed.nc" which can
  be used to load the data in other programs, e.g. Matlab or Python. Here,
  "squeezed" means that the measurement was preprocessed: It was rescaled
  according to the height scale factor, was detrended (if selected) and
  missing data points were filled in (if selected).

The metadata for the digital twins and the individual measurements can be
found in the auxiliary file 'meta.yml'. It is formatted as
[YAML](https://yaml.org/) file.

Version information
===================

TopoBank: 1.62.2
SurfaceTopography: 1.18.3
