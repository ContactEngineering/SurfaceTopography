
Contents of this ZIP archive
============================
This archive contains 1 surface(s). Each surface is a
collection of individual topography measurements.
In total 3 topography measurements are included.

The meta data for the surfaces and the individual topographies
can be found in the auxiliary file 'meta.yml'. It is formatted
as a [YAML](https://yaml.org/) file.

Version information
===================

TopoBank: 0.10.1

License information
===================

Some surfaces have been published under the following
licenses, please look at the metadata for each surface
for the specific license:


Creative Commons Attribution 4.0 International Public License
-------------------------------------------------------------
For details about this license see
- 'https://creativecommons.org/licenses/by/4.0/' (description), or
- 'https://creativecommons.org/licenses/by/4.0/legalcode' (legal code), or
- the included file 'LICENSE-ccby-4.0.txt' (legal code).
